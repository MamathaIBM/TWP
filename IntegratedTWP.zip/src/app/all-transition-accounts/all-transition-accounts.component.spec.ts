import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllTransitionAccountsComponent } from './all-transition-accounts.component';

describe('AllTransitionAccountsComponent', () => {
  let component: AllTransitionAccountsComponent;
  let fixture: ComponentFixture<AllTransitionAccountsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllTransitionAccountsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllTransitionAccountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
