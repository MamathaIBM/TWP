export class twbs {    
    Integration_ID : string = '' ;
    STANDARD_ACTIVITY_ID : string = '' ;
    STANDARD_ACTIVITY_NAME : string  = '' ;
    MILESTONE_OR_TASK : string = '' ;
    PHASE_NAME:string ='';
    STANDARD_ACTIVITY_CREATED_BY : string = '' ;
    STANDARD_ACTIVITY_LAST_UPDATED_BY : string = '' ;         
    STANDARD_ACTIVITY_CREATED_AT : string ='' ;
    STANDARD_ACTIVITY_LAST_UPDATED_AT : string = '';
    CheckedValue : number ;
    save :string;
    insert :string;
    Owner_Name : string;
    Comments : string;
    
}
export class twbsmodelSelection{
    PHASE_NAME :string;
}