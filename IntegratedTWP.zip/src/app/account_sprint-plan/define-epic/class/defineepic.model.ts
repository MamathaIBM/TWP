
export interface defineEpic {
    AppUNID : string;
    AppId: string;
    AppName :  string;
    Complexity : string ;
    Criticality : string ;
    Technology:string ;
    Vendor :  string ;
    appCategory : string;
    IntegrationID : string;
    createdDate : Date;
    modifiedDate : Date;
    createdBy : string;
    modifiedBy : string;
    save :string;
}
