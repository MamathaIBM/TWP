import { SprintPlanApplnLevelModule } from './sprint-plan-appln-level.module';

describe('SprintPlanApplnLevelModule', () => {
  let sprintPlanApplnLevelModule: SprintPlanApplnLevelModule;

  beforeEach(() => {
    sprintPlanApplnLevelModule = new SprintPlanApplnLevelModule();
  });

  it('should create an instance', () => {
    expect(sprintPlanApplnLevelModule).toBeTruthy();
  });
});
