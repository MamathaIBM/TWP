
export interface ApplicationServers {    
    appServerUNID : string;
    AppName  : string;
    Environment : string;
    serverType : string;
    serverName : string;
    IntegrationID :string;
    createdBy : string;
    modifiedBy : string;
}
