
export interface stInfoClass {
          MasterSTInfoid  : string;
          IntegrationID   : string;
          STScopeLevel    : string;
          STScope         : string;
          STDetailedScope : string;
          STScopeActivity : string;
          STToolUsage     : string;
          CREATED_BY      : string;
          MODIFIED_BY     : string;
          save :string;
}

