
export class Stakeholder {
    IntegrationID: string = '' ;
    Deliverablename: string  = '' ;
    Deliverablevalue: string = '' ;
}
