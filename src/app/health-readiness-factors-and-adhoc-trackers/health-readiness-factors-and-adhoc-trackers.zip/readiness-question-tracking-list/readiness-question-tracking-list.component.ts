import { Component, OnInit } from '@angular/core';

import { DataandparamService } from 'Services/dataandparam.service';
import { MatTableDataSource } from '@angular/material';
import {Router} from "@angular/router";
import { ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/filter';
import { UserAccessProfileService } from 'Services/user-access-profile.service';
import { NavtntService } from 'src/app/navtnt.service';
import { ReadinessQuestion } from 'Vo/readinessquestion';
import { ReadinessQuestionService } from 'Services/readinessquestion.service';
import { ReadinessQuestionsTracker } from 'Vo/readinessquestionstracker';
import { Observable, of } from 'rxjs';
import { delay, share } from 'rxjs/operators';
import { FormGroup, FormBuilder, FormArray, FormControl } from '@angular/forms';


@Component({
      selector: 'app-readiness-question-tracking-list',
      templateUrl: './readiness-question-tracking-list.component.html',
      styleUrls: ['./readiness-question-tracking-list.component.css']
})
export class ReadinessQuestionTrackingListComponent implements OnInit {

  transition_id:string="";

  parameterCustomId:string="";
  parameterName ="";
  dataLength = 0;
  readinessQuestionTrackerId:string='';
  filtersLoaded: Observable<boolean>;
  dataLoaded: Observable<{}>;
  formControlsColumnList:any[];  
  formRowList:any[];
  headerKeyValue: KeyValue={};
  resourceTypeMeasured = "";
 

  readinessQuestion: ReadinessQuestion = {
        readinessQuestionId:'',
        readinessQuestionCategory:'',
        readinessQuestion:'',
        readinessQuestionAnswerFieldType: '',
        readinessQuestionDataType: '',
        readinessQuestionAnswerSet:'', 
        readinessQuestionAnswer:'',  
        readinessQuestionDataList:[],
        adopted:'' 
  }


  readinessQuestionTracker: ReadinessQuestionsTracker = {
    readinessQuestionTrackerId:'',
    transitionId:'',
    applicationId:'',
    parameterCustomId:'',
    readinessQuestionCategory:'',
    multipleLogicalCols:'',
    criteriaMet:'',
    markForChange:false    
}


  readinessQuestions: any[] = [];
  readinessAnswers: any[] = [];

  questions: FormArray;

  existingReadinessQuestionJsonString: string="";
  readinessQuestionTrackingForm: FormGroup;


  //readinessQuestionTrackers:ReadinessQuestionsTracker[] = [];
  dataSource = new MatTableDataSource;
  //displayedColumns: string[] = [ 'readinessQuestionCategory', 'readinessQuestion','readinessQuestionAnswerFieldType', 'readinessQuestionId'];
  displayedColumns:any[]=[];


  constructor( private fb: FormBuilder, private route:ActivatedRoute,private navigation: NavtntService, private userAccessProfileService: UserAccessProfileService, private readinessQuestionService: ReadinessQuestionService, private dataandparamService: DataandparamService, private router: Router) { 


  }

  ngOnInit() {

          this.transition_id = this.userAccessProfileService.getCurrentTransitionID();
          this.readinessQuestionTrackingForm = this.fb.group({
            //readinessQuestionId:['']       
            //"readinessQuestionAnswer"+this.readinessQuestion.readinessQuestionId:''  
            questions:this.fb.array([])
                      
          });

          this.questions = this.readinessQuestionTrackingForm.get('questions') as FormArray;

          this.route.queryParams.subscribe((p: any) => {    
            if (p.filter){

                this.parameterCustomId = this.navigation.getParameterValue(p.filter, 'parameterId')   
                this.parameterName = this.navigation.getParameterValue(p.filter, 'parameterName')                   
                this.resourceTypeMeasured = this.navigation.getParameterValue(p.filter, 'resourceTypeMeasured')   

                this.getReadinessQuestionTrackingList();

                //alert("this.displayedColumns.length "+this.displayedColumns.length);
            }
          });         
          
  }

  get questionsArray(){
         return this.readinessQuestionTrackingForm.get('questions') as FormArray;
  }

  loadData() {
        // Fake Slow Async Data
        return of({
          dataLoaded: true
        }).pipe(
                delay(0)
        );
  }


  getReadinessQuestionTrackingList(){

    console.log( "getReadinessQuestionDesginList()"); 

    var applicationParameter = '{'+  
          '"transitionId":"'+this.transition_id+'", '+
          '"parameterId":"'+this.parameterCustomId+'" '+         
    '}'


    this.readinessQuestionService.getReadinessQuestionTrackingHeaderList(applicationParameter).subscribe((readinessQuestions:any[]) => {
                     
            console.log("###########################################");


            this.formControlsColumnList = readinessQuestions;
             // Form the HEADER METADATA

             //App Column Header
            let appColumnHeader: ReadinessQuestion = {
                      readinessQuestionId:'',
                      readinessQuestionCategory:'',
                      readinessQuestion:this.resourceTypeMeasured,
                      readinessQuestionAnswerFieldType: 'LABEL',
                      readinessQuestionDataType: '',
                      readinessQuestionAnswerSet:'' ,
                      readinessQuestionAnswer:'',  
                      readinessQuestionDataList:[]=[],
                      adopted:''                        
            }           


            this.headerKeyValue['RESOURCE_TYPE']=appColumnHeader;
            this.displayedColumns.push('RESOURCE_TYPE');


            // Answer Column Headers
            for(var p=0; p<readinessQuestions.length; p++) {

                      let readinessQuestion: ReadinessQuestion = {
                              readinessQuestionId:'',
                              readinessQuestionCategory:'',
                              readinessQuestion:'',
                              readinessQuestionAnswerFieldType: '',
                              readinessQuestionDataType: '',
                              readinessQuestionAnswerSet:'' ,
                              readinessQuestionAnswer:'',  
                              readinessQuestionDataList:[]=[],
                              adopted:''                        
                      }

                      readinessQuestion.readinessQuestionId = readinessQuestions[p].READINESS_QUESTION_CUSTOM_ID ;          
                      readinessQuestion.readinessQuestionCategory = readinessQuestions[p].READINESS_QUESTION_CATEGORY  ;
                      readinessQuestion.readinessQuestion = readinessQuestions[p].READINESS_QUESTION ;
                      readinessQuestion.readinessQuestionAnswerFieldType = readinessQuestions[p].READINESS_QUESTION_ANSWER_FIELD_TYPE ;
                      readinessQuestion.readinessQuestionDataType = readinessQuestions[p].READINESS_QUESTION_ANSWER_DATA_TYPE ;
                      readinessQuestion.readinessQuestionAnswerSet = readinessQuestions[p].READINESS_QUESTION_ANSWER_SET ;

                      var listValues1 = readinessQuestion.readinessQuestionAnswerSet.split(",");
                      for(var k=0; k<listValues1.length; k++) {
                            readinessQuestion.readinessQuestionDataList.push({id:listValues1[k], param:listValues1[k]})  
                      }
                
                      this.headerKeyValue[''+readinessQuestions[p].READINESS_QUESTION_CUSTOM_ID] = readinessQuestion;
                      this.displayedColumns.push(''+readinessQuestions[p].READINESS_QUESTION_CUSTOM_ID);     
            }

             //RAG Column Header
             let ragColumnHeader: ReadinessQuestion = {
                    readinessQuestionId:'',
                    readinessQuestionCategory:'',
                    readinessQuestion:'RAG',
                    readinessQuestionAnswerFieldType: 'DROPDOWN',
                    readinessQuestionDataType: '',
                    readinessQuestionAnswerSet:'R,A,G' ,
                    readinessQuestionAnswer:'',  
                    readinessQuestionDataList:[]=[],
                    adopted:''                        
              }  
              
             
              var listValues = ragColumnHeader.readinessQuestionAnswerSet.split(",");
              for(var m=0; m<listValues.length; m++) {
                   ragColumnHeader.readinessQuestionDataList.push({id:listValues[m], param:listValues[m]})  
              }              

              this.headerKeyValue['RAG']=ragColumnHeader;
              this.displayedColumns.push('RAG');


              var jsonParam = '{' +
                                    '"transitionId":"'+this.transition_id+'", '+
                                    '"resourceTypeMeasured":"'+this.resourceTypeMeasured+'", '+
                                    '"parameterId":"'+this.parameterCustomId+'" '+
                              '}'


            // Form the DATA /FORM CONTROL ROWS
            this.readinessQuestionService.getReadinessQuestionTrackingList(jsonParam).subscribe((readinessAnswers:any[]) => {

                      this.formRowList = [];
                      //this.questions = this.readinessQuestionTrackingForm.get('questions') as FormArray;

                      for(var x=0; x<readinessAnswers.length;x++){                                    
                                //this.displayedColumns = [];
                                
                                this.questions.push(this.fb.group({                                                
                                      questionId:readinessAnswers[x].READINESS_QUESTION_TRACKER_ID,                      
                                      answer:"", 
                                      markForChange:false         
                                })); 

                                                                
                                for(var q=0; q<readinessQuestions.length; q++) {                                        
                                          this.questions.push(this.fb.group({                                                
                                                  questionId:readinessQuestions[q].READINESS_QUESTION_CUSTOM_ID,                      
                                                  answer:"",  
                                                  markForChange:false        
                                          }));                                          
                                }

                                //RAG
                                this.questions.push(this.fb.group({                                                
                                  rag:readinessAnswers[x].READINESS_QUESTION_TRACKER_ID,                      
                                  answer:"", 
                                  markForChange:false         
                                })); 


                                //var obj = {};                                                           
                                this.readinessAnswers.push(this.getFormControlsRowData(readinessAnswers[x]) );                              
                                let readinessQuestionTracker: ReadinessQuestionsTracker = {
                                      readinessQuestionTrackerId:'',
                                      transitionId:'',
                                      applicationId:'',
                                      parameterCustomId:'',
                                      readinessQuestionCategory:'',
                                      multipleLogicalCols:'',
                                      criteriaMet:'',
                                      markForChange:false    
                              }

                              readinessQuestionTracker.readinessQuestionTrackerId = readinessAnswers[x].READINESS_QUESTION_TRACKER_ID;                                                    
                              readinessQuestionTracker.parameterCustomId = readinessAnswers[x].PARAMETER_CUSTOM_ID;
                              readinessQuestionTracker.transitionId = readinessAnswers[x].TRANSITION_ID;
                              readinessQuestionTracker.applicationId = readinessAnswers[x].RESOURCE_ID;
                              readinessQuestionTracker.multipleLogicalCols = readinessAnswers[x].MULTIPLE_LOGICAL_COLS;
                              
                              this.formRowList.push(readinessQuestionTracker);
                      }
                      

                      //alert("FormControl.length "+this.questions.length);
                      this.dataSource = new MatTableDataSource(this.readinessAnswers);

                      //alert("this.displayedColumns.length "+this.displayedColumns.length);
                      this.dataLength =  this.dataSource.data.length;
                      this.dataLoaded = this.loadData().pipe(share());
                      //alert("this.readinessAnswers "+this.readinessAnswers.length);
            });
          });    
    }


    getFormControlsRowData(readinessQuestionsTracker){

          var obj = {};          
          obj['RESOURCE_TYPE'] = readinessQuestionsTracker.RESOURCE_NAME;
          //alert("readinessQuestionsTracker.APP_NAME "+readinessQuestionsTracker.APP_NAME);
          //obj['HEADER_KEY_VALUE'] = headerKeyValue;
          //Parse MULTIPLE COLUMNS
          var multipleLogicalColumn = readinessQuestionsTracker.MULTIPLE_LOGICAL_COLS;


          //alert("multipleLogicalColumn "+multipleLogicalColumn);
          if (multipleLogicalColumn!=''){

                //alert("readinessQuestionsTracker.APP_NAME "+readinessQuestionsTracker.APP_NAME);
                var multipleLogicalColumnForAnswers = JSON.parse(multipleLogicalColumn);
                              
                for(var i=0; i<multipleLogicalColumnForAnswers.length; i++) {
                        obj[''+multipleLogicalColumnForAnswers[i].Q_ID]=multipleLogicalColumnForAnswers[i].ANSWER;              
                }
          }

          obj['RAG'] = readinessQuestionsTracker.RAG;

          return obj;
    }



    /*

      this.formRowList = [];
      for(var x=0; x<3; x++) {
     
      this.formControlsColumnList=[];      
      this.displayedColumns = [];

      // The below loop should traverse for each application

      var obj = { };
      for(var i=0; i<readinessQuestions.length; i++) {
                                          
                    console.log("Value of i"+i);
                    let readinessQuestion: ReadinessQuestion = {
                          readinessQuestionId:'',
                          readinessQuestionCategory:'',
                          readinessQuestion:'',
                          readinessQuestionAnswerFieldType: '',
                          readinessQuestionDataType: '',
                          readinessQuestionAnswerSet:'' ,
                          readinessQuestionAnswer:'',  
                          readinessQuestionDataList:[]=[]                        
                    }
                    
                   this.questions = this.readinessQuestionTrackingForm.get('questions') as FormArray;
                   

                    readinessQuestion.readinessQuestionId = readinessQuestions[i].READINESS_QUESTION_CUSTOM_ID ;          
                    readinessQuestion.readinessQuestionCategory = readinessQuestions[i].READINESS_QUESTION_CATEGORY  ;
                    readinessQuestion.readinessQuestion = readinessQuestions[i].READINESS_QUESTION ;
                    readinessQuestion.readinessQuestionAnswerFieldType = readinessQuestions[i].READINESS_QUESTION_ANSWER_FIELD_TYPE ;
                    readinessQuestion.readinessQuestionDataType = readinessQuestions[i].READINESS_QUESTION_ANSWER_DATA_TYPE ;
                    readinessQuestion.readinessQuestionAnswerSet = readinessQuestions[i].READINESS_QUESTION_ANSWER_SET ;


                    this.questions.push(this.fb.group({
                      category:readinessQuestion.readinessQuestionCategory,
                      question:readinessQuestion.readinessQuestion,                      
                      answer:''          
                      }));


                    
                    var listValues = readinessQuestion.readinessQuestionAnswerSet.split(",");
                    for(var k=0; k<listValues.length; k++) {
                          readinessQuestion.readinessQuestionDataList.push({id:listValues[k], param:listValues[k]})  
                    }  

                    //this.readinessQuestions.push(readinessQuestion);

                   // this.displayedColumns.push(readinessQuestion.readinessQuestionId);
                    obj[''+readinessQuestion.readinessQuestionId]=readinessQuestion;


                    this.formControlsColumnList.push(readinessQuestion);

                    this.displayedColumns.push(''+readinessQuestions[i].READINESS_QUESTION_CUSTOM_ID);      
                    
                    //alert(readinessQuestions[i].READINESS_QUESTION);
                }

                this.readinessQuestions.push(obj);
                this.formRowList.push(this.formControlsColumnList);
                this.formControlsColumnList = [];
              } // End of outer for loop




                this.dataSource = new MatTableDataSource(this.readinessQuestions);

                this.dataLength =  this.dataSource.data.length;

                //alert("this.dataLength  "+this.dataLength);
                //alert("this.displayedColumns.length  "+this.displayedColumns.length);

               
                setTimeout(function() {
                  this.filtersLoaded = Promise.resolve(true);
              }, 8000);

                   
             
             this.dataLoaded = this.loadData().pipe(share());
      
    });    
  }

*/
  /*
  getReadinessQuestionTrackingList(){

    console.log(  "getReadinessQuestionDesginList()"); 

    this.readinessQuestionService.getReadinessQuestionTrackingList(this.transition_id).subscribe((readinessQuestionTrackers:any[]) => {
                     
      console.log("###########################################");
      for(var j=0; j<readinessQuestionTrackers.length; j++) {
              
                this.readinessQuestionTrackerId = readinessQuestionTrackers[j].READINESS_QUESTION_TRACKER_ID;
                //alert("readinessQuestionTracker[i].MULTIPLE_LOGICAL_COLS= "+readinessQuestionTrackers[j].MULTIPLE_LOGICAL_COLS)                
                this.existingReadinessQuestionJsonString = readinessQuestionTrackers[j].MULTIPLE_LOGICAL_COLS;
                var readinessQuestions = JSON.parse(this.existingReadinessQuestionJsonString);
                              
                for(var i=0; i<readinessQuestions.length; i++) {

                    console.log("Value of i"+i);
                    let readinessQuestion: ReadinessQuestion = {
                          readinessQuestionId:'',
                          readinessQuestionCategory:'',
                          readinessQuestion:'',
                          readinessQuestionAnswerFieldType: '',
                          readinessQuestionDataType: '',
                          readinessQuestionAnswerSet:'' ,
                          readinessQuestionAnswer:'',  
                          readinessQuestionDataList:[]=[]                        
                    }
                    
                    this.questions = this.readinessQuestionTrackingForm.get('questions') as FormArray;
                   

                    readinessQuestion.readinessQuestionId = readinessQuestions[i].Q_ID ;          
                    readinessQuestion.readinessQuestionCategory = readinessQuestions[i].Q_CAT  ;
                    readinessQuestion.readinessQuestion = readinessQuestions[i].Q ;
                    readinessQuestion.readinessQuestionAnswerFieldType = readinessQuestions[i].Q_FIELD_TYPE ;
                    readinessQuestion.readinessQuestionDataType = readinessQuestions[i].Q_DATA_TYPE ;
                    readinessQuestion.readinessQuestionAnswerSet = readinessQuestions[i].Q_ANSWER_SET ;


                    this.questions.push(new FormControl(readinessQuestion.readinessQuestionId));

                    
                    var listValues = readinessQuestion.readinessQuestionAnswerSet.split(",");
                    for(var k=0; k<listValues.length; k++) {
                          readinessQuestion.readinessQuestionDataList.push({id:listValues[k], param:listValues[k]})  
                    }  

                    this.readinessQuestions.push(readinessQuestion);
                }

                this.dataSource = new MatTableDataSource(this.readinessQuestions);
                this.dataLength =  this.dataSource.data.length;

          
             
             this.dataLoaded = this.loadData().pipe(share());
      }
    });    
  }
  */

  




  /*
  onDelete(readinessQuestion) {
    console.log("Delete Clicked "+readinessQuestion.readinessQuestionId);    
    this.deleteReadinessQuestion(readinessQuestion.readinessQuestionId);
  }

  */


  onUpdate(readinessQuestion) {
    console.log("Update Clicked "+readinessQuestion.readinessQuestionId);    
    //this.router.navigate(['/admin-home/readinessQuestion-list/'+readinessQuestion.readinessQuestionId]);
    //this.router.navigate(['/admin-home/readinessQuestion-edit/'+readinessQuestion.readinessQuestionId]);
    //this.router.navigate(["/admin-home/readinessQuestion-edit"],{queryParams:{readinessQuestionId:readinessQuestion.readinessQuestionId}})
    //this.router.navigate(["/admin-home/readinessQuestion-edit/"+readinessQuestion.readinessQuestionId])

    //this.router.navigate(["/admin-home/controller-admin"],{queryParams:{destination:'/admin-home/readinessQuestion-list'}}) 

    /*
    var myQueryParams = [
      { id: 'destination', param: '/admin-home/readinessQuestion-edit' },
      { id: 'readinessQuestionId', param: readinessQuestion.readinessQuestionId }      
    ];
    */

    //this.router.navigate(['/admin-home/controller-admin'], {queryParams: {filter: JSON.stringify(myQueryParams)}})


    //var controllerPath = '/controller-tnt'
    var sourceComponentPath = "/admin-home/readiness-question-list";
    var destinationComponentPath = "/admin-home/readiness-question-edit";
    var destinationComponentParameterArray = [{ id: 'readinessQuestionId', param: readinessQuestion.readinessQuestionId } ]     
  
    this.navigation.goToComponent(sourceComponentPath,destinationComponentPath,destinationComponentParameterArray)    

  }



  createNew(readinessQuestionTrackerId) {
    //console.log("copyAndCreateNew Clicked "+readinessQuestionId);   
    //this.router.navigate(["/admin-home/readinessQuestion-add"],{queryParams:{readinessQuestionId:readinessQuestionId}}) 
    //this.router.navigate(['controller-tnt', 'readinessQuestion-add/'+readinessQuestionId]);
    var controllerPath = "/admin-home/controller-admin";
    var sourceComponentPath = "/admin-home/readiness-question-design-list";
    var destinationComponentPath = "/admin-home/readiness-question-design-add";
    var destinationComponentParameterArray = [{ id: 'readinessQuestionTrackerId', param: this.readinessQuestionTrackerId },
                                              { id: 'existingReadinessQuestionJsonString', param: this.existingReadinessQuestionJsonString } ] 

  
    this.navigation.goToComponent(sourceComponentPath,destinationComponentPath,destinationComponentParameterArray)    

  }


   save(){

    //alert("Inside save");
    var overallRowChangeCounter = 0;
    var overallJSON = "";
    for(var j=0; j<this.formRowList.length; j++) {

            if (this.formRowList[j].markForChange){
                    var response = "";
                    var count = 0;                  
                    var numberOfColumns = this.formControlsColumnList.length;
                    // because of RAG column one less number of columns to be considered
                    for(var i=0; i<numberOfColumns; i++) {
                            if (count>0){
                                response = response +",";
                            }

                            response = response + '{' +
                                      '"Q_ID":"'+this.formControlsColumnList[i].READINESS_QUESTION_CUSTOM_ID+'",'+          
                                      '"ANSWER":"'+(this.readinessQuestionTrackingForm.get('questions')).controls[j*(numberOfColumns)+(j*2)+(i+1)].value.answer+
                              '"}';

                              //alert("XXX "+(j*(numberOfColumns)+(j*2)+(i+1)));

                            //alert("response "+response);   
                           // Update the readiness list with the latest change
                           // (this.readinessAnswers[j])[''+this.formControlsColumnList[i].READINESS_QUESTION_CUSTOM_ID] = (this.readinessQuestionTrackingForm.get('questions')).controls[j*(numberOfColumns)+i+1].value.answer;

                            count = count + 1;      
                    }
                    var multipleColumnsValue = '[' + response + ']'
                    //alert("multipleColumnsValue"+multipleColumnsValue);


                    //var rag = this.formControlsColumnList[numberOfColumns-1];
                    //alert("numberOfColumns "+numberOfColumns);
                    //alert("counter"+((j+1)*(numberOfColumns)+j*2+1));
                    var rag = (this.readinessQuestionTrackingForm.get('questions')).controls[(j+1)*(numberOfColumns)+j*2+1].value.answer;
                    //alert("j*(numberOfColumns)+(numberOfColumns-1)+1"+j*(numberOfColumns)+(numberOfColumns)+1);

                    if (overallRowChangeCounter>0){
                            overallJSON = overallJSON +",";
                    }

                    overallJSON = overallJSON + '{' +
                                            '"READINESS_QUESTION_TRACKER_ID":"'+this.formRowList[j].readinessQuestionTrackerId+'",'+          
                                            '"PARAMETER_CUSTOM_ID":"'+this.parameterCustomId+'",'+   
                                            '"TRANSITION_ID":"'+this.transition_id+'",'+   
                                            '"READINESS_QUESTION_MEASURED_AGAINST_PARAMETER_VALUE":"'+this.formRowList[j].applicationId+'",'+   
                                            '"MULTIPLE_LOGICAL_COLS":'+multipleColumnsValue+', '+   
                                            '"RAG":"'+rag+'" '+   
                    '}';

                    overallRowChangeCounter = overallRowChangeCounter + 1;
            }               
  }

  overallJSON = '[' + overallJSON + ']';


  if (overallRowChangeCounter>0){ // Then only submit

    
    //alert("overallJSON "+overallJSON);
    var parameterJSON ='{' +
                        '"PARAMETER":'+overallJSON +''+                  
                       '}'
                       console.log("overall Json "+parameterJSON);
    
      console.log("##################################################################################################");

        // mark the row change for false 
        for(var j=0; j<this.formRowList.length; j++) {
            if (this.formRowList[j].markForChange){
                  this.formRowList[j].markForChange = false;
            }
        } 
    
      
      var sourceComponentPath = '/transition-Main/readiness-question-tracking-list';
      var destinationComponentPath = '/transition-Main/readiness-question-tracking-save';
      var destinationComponentParameterArray =  [
                                                    { id: 'jsonRecords', param: parameterJSON },
                                                    { id: 'transition_id', param: this.transition_id },
                                                    { id: 'parameterId', param: this.parameterCustomId },
                                                    { id: 'resourceTypeMeasured', param: this.resourceTypeMeasured },
                                                    { id: 'parameterName', param: this.parameterName }, 
                                                    { id: 'returnPath', param: sourceComponentPath }                                                    
                                                ]     
      this.navigation.goToComponent(sourceComponentPath,destinationComponentPath,destinationComponentParameterArray)                  
      
      
  }


    //alert(this.readinessQuestion.readinessQuestionId)
   // alert("readinessQuestionAnswer"+this.readinessQuestionTrackingForm.get('readinessQuestionAnswer'+'Cat').value);

    //alert(readinessQuestionTrackingForm.);



  }

  onChange(rowIndex){

        //alert("onChange called "+rowIndex);

        //alert(" this.formRowList[rowIndex].markForChange  "+this.formRowList[rowIndex].markForChange );
        //alert(" this.formRowList[rowIndex].readinessQuestionTrackerId "+this.formRowList[rowIndex].readinessQuestionTrackerId);
        this.formRowList[rowIndex].markForChange = true;        
        //alert("onChange is done")
  }


  onDelete(headerElement){

    //alert(" headerElement.readinessQuestionId "+headerElement.readinessQuestionId);

    var applicationParameter = '{'+  
          '"readinessQuestionId":"'+headerElement.readinessQuestionId+'", '+
          '"parameterCustomId":"'+this.parameterCustomId+'" '+         
    '}'

    this.readinessQuestionService.checkReadinessQuestionData(applicationParameter ).subscribe((containsData:any[]) => {                      
          if (containsData.length >0){
              if(confirm("You have captured reponses against this question. Data will be lost if you delete. Are you sure to delete?")) {
                var sourceComponentPath = '/transition-Main/readiness-question-tracking-list';
                var destinationComponentPath = '/transition-Main/readiness-question-tracking-delete';
                var destinationComponentParameterArray =  [
                                                              { id: 'jsonRecords', param: applicationParameter },
                                                              { id: 'transition_id', param: this.transition_id },
                                                              { id: 'parameterId', param: this.parameterCustomId },
                                                              { id: 'resourceTypeMeasured', param: this.resourceTypeMeasured },
                                                              { id: 'parameterName', param: this.parameterName }, 
                                                              { id: 'returnPath', param: sourceComponentPath }                                                    
                                                          ]     
                this.navigation.goToComponent(sourceComponentPath,destinationComponentPath,destinationComponentParameterArray)                  
              }
          }    
          else{
            if(confirm("You have NOT captured any reponse against this question. It is safe to delete. Are you sure to delete?")) {
              var sourceComponentPath = '/transition-Main/readiness-question-tracking-list';
              var destinationComponentPath = '/transition-Main/readiness-question-tracking-delete';
              var destinationComponentParameterArray =  [
                                                            { id: 'jsonRecords', param: applicationParameter },
                                                            { id: 'transition_id', param: this.transition_id },
                                                            { id: 'parameterId', param: this.parameterCustomId },
                                                            { id: 'resourceTypeMeasured', param: this.resourceTypeMeasured },
                                                            { id: 'parameterName', param: this.parameterName }, 
                                                            { id: 'returnPath', param: sourceComponentPath }                                                    
                                                        ]     
              this.navigation.goToComponent(sourceComponentPath,destinationComponentPath,destinationComponentParameterArray)                  
            }

          }
    });

   

 }


  addOrUpdateReadinessQuestionTracking(){

 
}
readinessQuestionTrackingLandscapeList(parameterId,parameterName, resourceTypeMeasured){

  var sourceComponentPath = '/transition-Main/readiness-question-tracking-list';
  var destinationComponentPath = '/transition-Main/readiness-question-tracking-landscape-list';
  var destinationComponentParameterArray:any =  [{ id: 'parameterId', param: parameterId },
  { id: 'parameterName', param: parameterName },
  { id: 'resourceTypeMeasured', param: resourceTypeMeasured }  ]     

  this.navigation.goToComponent(sourceComponentPath,destinationComponentPath,destinationComponentParameterArray)    
}

}

export interface KeyValue {
  [id :string]: ReadinessQuestion;
}